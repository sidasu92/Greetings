({
	assignUserId : function(component, event){
		var action = component.get("c.assignUser");
        var getSelectUser = component.get("v.oUser");
        action.setParams({ userId : getSelectUser.Name});
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            console.log(actionResult.getReturnValue());
            //component.set('vassignUserId', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
})