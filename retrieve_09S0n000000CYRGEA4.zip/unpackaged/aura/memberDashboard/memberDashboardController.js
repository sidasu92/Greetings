({	
    doInit : function(component, event, helper) {
        var action = component.get('c.getYears');
        var action2 = component.get('c.getMembers');
        var action3 = component.get('c.getQuarters');
        //var action4 = component.get("c.getOpps");
        // Set up the callback
        action2.setCallback(this, function(actionResult) {
            component.set('v.member', actionResult.getReturnValue());
            
        });
        action.setCallback(this, function(actionResult) {
            component.set('v.allYears', actionResult.getReturnValue());
            
        });
        action3.setCallback(this, function(actionResult) {
            component.set('v.quarters', actionResult.getReturnValue());
            
        });
        /* action4.setCallback(this, function(actionResult) {
            component.set("v.opps", actionResult.getReturnValue());
         	component.set("v.oppsLength", actionResult.getReturnValue().length); 
       	});*/
        
        $A.enqueueAction(action);
        $A.enqueueAction(action2); 
        $A.enqueueAction(action3);
        // $A.enqueueAction(action4);
    },
    
    
    
    onSelectUser : function(component, event, helper) {
        var action = component.get('c.getOpps');
        action.setParams({ user : component.find("Member").get("v.value"), 
                          year : component.find("Year").get("v.value"),
                          quarter : component.find("Quarter").get("v.value")});
        
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            
            var opps = actionResult.getReturnValue();
            
            var sums = {tExp : 0 , tAtt : 0, tErn : 0, tDis : 0, tOwn : 0, tBen : 0, tFin : 0};
            
            for (var x = 0; x < opps.length; x++){
                var opp = opps[x];
                if(opp.totalOut){}
                else{opp.totalOut = 0};
                if(opp.Splits__r){
                    for(var s = 0; s < opp.Splits__r.length; s++) {
                        var spl = opp.Splits__r[s]
                        sums.tExp += spl.Receivable_Estimate__c;
                        sums.tAtt += spl.Attribution__c;
                        sums.tErn += spl.Earned__c;
                        sums.tDis += spl.Receivable_Payments__c;
                        //if(spl.Project_Record_Type__c != 'Benefits'){
                        	sums.tOwn += spl.Owed__c;
                        //}
                        if(spl.Project_Record_Type__c == 'Benefits'){
                            sums.tBen += spl.Receivable_Payments__c;
                        }
                        //opp.totalOut += spl.Owed__c //(spl.Owed__c - sums.tBen) ;
                        
                        opp.totalOut += spl.Owed__c ;
                        //sums.tOwn - sums.tBen;
                    }
                }
                opp.totalOut = opp.totalOut - sums.tBen;
                sums.tFin += opp.totalOut;
                sums.tErn = sums.tErn - sums.tBen;
            }
            
            
            component.set('v.sums' , sums);
            component.set('v.getOppsList', actionResult.getReturnValue());
            component.set("v.opps", actionResult.getReturnValue());
            component.set("v.oppsLength", actionResult.getReturnValue().length); 
            
        });
        
        
        $A.enqueueAction(action);
        
    },
    
    payTotal : function(component, event, helper) {
        var opps = component.get("v.getOppsList")
        
        var totalPay = 0                    
        for (var x = 0 ; x <opps.length; x++) {                                
            var opp = opps[x];
            if(opp.Splits__r){
                for(var s = 0; s < opp.Splits__r.length; s++) {
                    var spl = opp.Splits__r[s]
                    if(spl.pay__c)totalPay += spl.pay__c;
                }
            }
        }             
        component.set('v.totalPay',totalPay);
        console.log(totalPay);
        
        // logic to hide and display Make Payment button depending on the values of Pay Now fields
        var allTotalOwed = component.find('totalOwed');
        var allPayNow = component.find('payNow');
        
        for(var i = 0; i < allTotalOwed.length; i++) {
            if(allPayNow[i].get("v.value") > allTotalOwed[i].get("v.value")) {
                component.find("PaymentBtn").set("v.class", "hideSubmitBtn");
/*
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'sticky',
                    message: 'Please enter a value lower than Owed value!',
                    type: 'error'
                });
                toastEvent.fire();*/
                break;
            } else {
                component.find("PaymentBtn").set("v.class", "showSubmitBtn");
            }
        }
    },  
    
    redirectToSobject: function(component, event) {
        var selectedItem = event.currentTarget;
        var IdP = selectedItem.dataset.record;
        
        if ((typeof sforce != 'undefined') && sforce && (!!sforce.one))
            sforce.one.navigateToSObject(IdP);
        else{
            location.href = '/' + IdP;
        }
    },
    
    createInvoice : function(component, event, helper) {
        console.log('getOppsList:: ');
        console.log(component.get('v.getOppsList'));
        var oppList = component.get('v.getOppsList');
        var mapToSend = {}
        for (var x = 0 ; x <oppList.length; x++) {
            
            var opp = oppList[x];
            console.log(opp);
            if(opp.Splits__r) {
                for(var s = 0; s < opp.Splits__r.length; s++) {
                    var spl = opp.Splits__r[s]
                    console.log(spl.Id);
                    console.log(spl.pay__c);
                    if(spl.pay__c == null) {
                        mapToSend[spl.Id] = 0.0;
                    } else {
                        mapToSend[spl.Id] = spl.pay__c;
                    }
                    
                }
                
            }
        }   
        console.log('mapToSend:: ')
        console.log(mapToSend);
        
        var action = component.get('c.makePayments');
        action.setParams({ 'splitPayMap' : JSON.stringify(mapToSend)});
        action.setCallback(this, function(actionResult) {
            console.log('action performed!');
            helper.onSelectUser(component, event);
            var state = actionResult.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + actionResult.getReturnValue());
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'success',
                    message: 'Success! Payment Processed!'
                });
                toastEvent.fire();
            }
            else if (state === "INCOMPLETE") {
                // do something
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'error',
                    message: 'Error! Please contact your System Administrator!'
                });
                toastEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'error',
                    message: 'Error! Please contact your System Administrator!'
                });
                toastEvent.fire();
            }
            
        });
        
        $A.enqueueAction(action);
    }
    
    
    
})