({
    onSelectUser : function(component, event) {
        var action = component.get('c.getOpps');
        action.setParams({ user : component.find("Member").get("v.value"), 
                          year : component.find("Year").get("v.value"),
                          quarter : component.find("Quarter").get("v.value")});
        
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            
            var opps = actionResult.getReturnValue();
            
            var sums = {tExp : 0 , tAtt : 0, tErn : 0, tDis : 0, tOwn : 0};
            
            for (var x = 0; x < opps.length; x++){
                var opp = opps[x];
                if(opp.totalOut){}
                else{opp.totalOut = 0};
                if(opp.Splits__r){
                    for(var s = 0; s < opp.Splits__r.length; s++) {
                        var spl = opp.Splits__r[s]
                        sums.tExp += spl.Receivable_Estimate__c;
                        sums.tAtt += spl.Attribution__c;
                        sums.tErn += spl.Earned__c;
                        sums.tDis += spl.Receivable_Payments__c;
                        sums.tOwn += spl.Owed__c;
                        opp.totalOut += spl.Owed__c;
                    }
                }
            }
            
            component.set('v.sums' , sums);
            component.set('v.getOppsList', actionResult.getReturnValue());
            component.set("v.opps", actionResult.getReturnValue());
            component.set("v.oppsLength", actionResult.getReturnValue().length); 
            
        });
        
        
        $A.enqueueAction(action);
        
    },
})