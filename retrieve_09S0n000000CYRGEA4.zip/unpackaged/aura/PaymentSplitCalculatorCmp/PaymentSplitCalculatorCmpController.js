({
    doInit : function(component, event, helper) {
        var action = component.get('c.getCountriesSelectList');
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            component.set('v.allYears', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    onSelectYear : function(component, event, helper) {
        var action = component.get('c.filterProjects');
        action.setParams({ accId : component.find("years").get("v.value")});
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            console.log('actionResult.getReturnValue(): '+actionResult.getReturnValue());
            component.set('v.filteredProjects', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    populateReceivable : function(component, event, helper) {
        var action = component.get('c.relatedReceivable');
        action.setParams({opportunityId : component.find("projects").get("v.value"), yearVal : component.find("years").get("v.value")});
        action.setCallback(this, function(actionResult){
            console.log('populateReceivable actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());  
        });
        $A.enqueueAction(action);
		        
    },
    addSplitWrapperJS : function(component, event, helper) {
        var action = component.get('c.addSplitWrapper');
        var usrCls = event.currentTarget.getAttribute("data-data") || event.currentTarget.parentNode.getAttribute("data-data")
        //console.log(usrCls);
        console.log(JSON.stringify(component.get("v.classVar")));
        action.setParams({ 'controllerVarJSON' : JSON.stringify(component.get("v.classVar")) });
        action.setCallback(this, function(actionResult){
            console.log('populateReceivable actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    removeSplitWrapperJS : function(component, event, helper) {
        var userId = event.currentTarget.getAttribute("data-data") || event.currentTarget.parentNode.getAttribute("data-data")
        console.log(userId);
        var action = component.get('c.removeSplitWrapper');
        action.setParams({ 'controllerVarJSON' : JSON.stringify(component.get("v.classVar")), 'userId' : userId, 'opptyId' : component.find("projects").get("v.value"), 'yearVal' : component.find("years").get("v.value")});
        action.setCallback(this, function(actionResult){
            console.log('removeSplitWrapperJS actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    handleChildComponentEvent : function(component, event, helper) {
        // get the selected Account record from the COMPONENT event 	 
        var selectedUserGetFromEvent = event.getParam("userByEvent");
        console.log('selectedUserGetFromEvent in parent: : ');
        console.log(selectedUserGetFromEvent.Name);
        
        var action = component.get('c.updateUser');
        action.setParams({'userName' : selectedUserGetFromEvent.Name, 'userId' : selectedUserGetFromEvent.Id, 'lstSplitWrapperJSON' : JSON.stringify(component.get("v.classVar.lstSplitWrapper"))});
        action.setCallback(this, function(actionResult) {
            console.log('handleChildComponentEvent actionResult: ');
            console.log(actionResult.getReturnValue());
            component.set('v.classVar.lstSplitWrapper', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    checkSum : function(component, event, helper) {

        var whichOne = event.getSource().getLocalId();
        var getAll = [];
        // handle undefined when only one row of receivable is present
        var receviables = component.find(whichOne);
        if(receviables.length != undefined) {
            getAll = component.find(whichOne);
        } else {
            getAll.push(component.find(whichOne));
        }
        var sum = 0;
        // play a for loop and check every checkbox values 
        // if value is checked(true) then add those Id (store in Text attribute on checkbox) in tempIDs var.
        for (var i = 0; i < getAll.length; i++) {
            console.log('in for loop for sum');
            console.log(getAll[i].get("v.value"));
            sum+=parseFloat(getAll[i].get("v.value"));
        }
        // set sum value
        var sumCls = whichOne.replace(/P\s*$/, "");
        component.find(sumCls).set("v.value", sum);
        var changeCls = component.find(sumCls).get("v.class");
		console.log(changeCls);        
        if(changeCls.includes('red')) {
            if(sum < 101) {
                changeCls = changeCls.replace("red", "");
                console.log('in if '+changeCls); 
                component.find(sumCls).set("v.class", changeCls);
                component.find("splitSubmitBtn").set("v.class", "showSubmitBtn");
            } else {
                //do nothing
            }
        } else {
            if(sum > 100) {
                changeCls+=' red';
                component.find(sumCls).set("v.class", changeCls);
                console.log(component.find("splitSubmitBtn"));
                component.find("splitSubmitBtn").set("v.class", "hideSubmitBtn");
                
            } else {
                //do nothing
            }
        }
    },
	attributeVal : function(component, event, helper) {
        
        
        var abc = component.find("act");
        for (var key in component.find("act")) {
            console.log(key);
            console.log(abc[key].get("v.value"));
        }
    },
    closeModal:function(component,event,helper) {
        
        //  clear receivable Id
        component.set('v.receivableID', '');
        
        var cmpTarget = component.find('Modalbox');
        var cmpBack = component.find('Modalbackdrop');
        $A.util.removeClass(cmpBack,'slds-backdrop--open');
        $A.util.removeClass(cmpTarget, 'slds-fade-in-open');
    },
    openModal: function(component,event,helper) {
        // get the receivable id and type of receivable in csv
        var receivableId = event.target.id;
        
        var idTypeArr = []
        idTypeArr = receivableId.split(',');
        console.log('idTypeArr[0]:: '+idTypeArr[0]);
        if(idTypeArr[0] === '') {
            idTypeArr[0] = null;
        }
        console.log('idTypeArr[0]:: '+idTypeArr[0]);
        // set id into variable receivableID for submit use
        component.set('v.receivableID', idTypeArr[0]);
        
        // idTypeArr[1] will contain type of receivable for apex to process
        component.set('v.typeOfReceivable', idTypeArr[1])
        
        // idTypeArr[2] will contain month for apex to process
        component.set('v.selectedMonth', idTypeArr[2]);
        console.log(idTypeArr[2]);
        
        // prepare JS to call Apex method to populate Modal
        var action = component.get('c.populateReceivables');
        action.setParams({ 'receivableId' : idTypeArr[0], 'typeOfReceivable' : idTypeArr[1]});
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            // get all 8 values and separate first 4 and next 4
            var lstReceivable = actionResult.getReturnValue();
            console.log('lstReceivable:: '+lstReceivable);
            var successList = [];
            var retainerList = [];
            for(var i = 0; i < lstReceivable.length; i++) {
                if(i<4) {
                    successList.push(lstReceivable[i]);
                } else {
                    retainerList.push(lstReceivable[i]);
                }
            }
            
            // populate in attributes
            component.set('v.modalSuccessLst', successList);
            component.set('v.modalRetainerLst', retainerList);
            console.log(successList + ' : : ' +retainerList);
            console.log(successList + ' : : ' +retainerList);
            console.log(successList + ' : : ' +retainerList);
            console.log(successList + ' : : ' +retainerList);
            
        });
        $A.enqueueAction(action);
        
        // show modal
        var cmpTarget = component.find('Modalbox');
        var cmpBack = component.find('Modalbackdrop');
        $A.util.addClass(cmpTarget, 'slds-fade-in-open');
        $A.util.addClass(cmpBack, 'slds-backdrop--open'); 
    },
    submitModal: function(component,event,helper) {
        console.log(component.find("projects").get("v.value") +  component.get('v.selectedMonth') + component.find("years").get("v.value"));
        // store 8 decimal values in this list to feed to apex controller
        var modalList = [];
        var modVals = component.find("modalValues");
        for (var key in modVals) {
            modalList.push(modVals[key].get("v.value"));
        }
        var action = component.get('c.insertUpdateReceivable');
        action.setParams({'successLst' : modalList, 'receivableId' : component.get('v.receivableID'), 'typeOfReceivable': component.get('v.typeOfReceivable'),'selMonth' : component.get('v.selectedMonth'),'selYear' : component.find("years").get("v.value"), 'selProject' : component.find("projects").get("v.value")});
        action.setCallback(this, function(actionResult) {
            console.log('submitModal actionResult: ');
            helper.populateReceivable(component,event);
            helper.closeModal(component,event);
        });
        $A.enqueueAction(action);
    },
    submitSplitJS : function(component, event, helper) {
        console.log(JSON.stringify(component.get('v.classVar.lstSplitWrapper')));
        console.log(component.find("projects").get("v.value") +  component.get('v.selectedMonth') + component.find("years").get("v.value"));
        
        // populate a map of month to receivables
        
        
        var action = component.get('c.submitSplitApex');
        action.setParams({'lstSplitWrapperJSON': JSON.stringify(component.get('v.classVar.lstSplitWrapper')), 'selYear' : component.find("years").get("v.value"), 'selProject' : component.find("projects").get("v.value")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + response.getReturnValue());
                
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
        // check if the user is selected in lookup
        if($('.userIdJS') != undefined 
           && $('.userIdJS') != null 
           && $('.userIdJS').text() != ''
           && $('.userIdJS').text() != null 
           && $('.userIdJS').text() != undefined ) {
            
            console.log('Hi, value found!');
        }
    }
})