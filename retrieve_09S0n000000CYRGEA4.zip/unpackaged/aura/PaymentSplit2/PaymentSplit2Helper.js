({
    searchHelper : function(component,event,getInputkeyWord) {
        
    },
    populateModal : function(component, event) {
        
    },
    closeModal:function(component,event) {
        
        //  clear receivable Id
        component.set('v.receivableID', '');
        
        var cmpTarget = component.find('Modalbox');
        var cmpBack = component.find('Modalbackdrop');
        $A.util.removeClass(cmpBack,'slds-backdrop--open');
        $A.util.removeClass(cmpTarget, 'slds-fade-in-open');
    },
    populateReceivable : function(component, event) {
        var action = component.get('c.relatedReceivable');
        action.setParams({opportunityId : component.find("projects").get("v.value"), yearVal : component.find("years").get("v.value")});
        action.setCallback(this, function(actionResult){
            component.set('v.classVar', actionResult.getReturnValue());         
        });
        $A.enqueueAction(action);
    },
    calculateAllSum : function(component) {
        $(document).ready(function(){
            var months = ['janP', 'febP', 'marP', 'aprP', 'mayP', 'junP', 'julP', 'augP', 'sepP', 'octP', 'novP', 'decP'];
            for(var i=0; i<12; i++) {
                var getAll = [];
                // handle undefined when only one row of receivable is present
                var receviables = component.find(months[i]);
                if(receviables.length != undefined) {
                    getAll = component.find(months[i]);
                } else {
                    getAll.push(component.find(months[i]));
                }
                var sum = 0;
                // play a for loop and check every checkbox values 
                // if value is checked(true) then add those Id (store in Text attribute on checkbox) in tempIDs var.
                if( getAll.length != undefined ) {
                    //alert(getAll.length);
                    for (var j = 0; j < getAll.length; j++) {
                        sum+=parseFloat(getAll[j].get("v.value"));
                    }
                    // set sum value
                    var sumCls = months[i].replace(/P\s*$/, "");
                    component.find(sumCls).set("v.value", sum);
                    var changeCls = component.find(sumCls).get("v.class");
                    if(changeCls.includes('red')) {
                        if(sum < 101) {
                            changeCls = changeCls.replace("red", "");
                            component.find(sumCls).set("v.class", changeCls);
                            component.find("splitSubmitBtn").set("v.class", "showSubmitBtn");
                        } else {
                            //do nothing
                        }
                    } else {
                        if(sum > 100) {
                            changeCls+=' red';
                            component.find(sumCls).set("v.class", changeCls);
                            component.find("splitSubmitBtn").set("v.class", "hideSubmitBtn");
                        } else {
                            //do nothing
                        }
                    }
                }
                
            }
        });
    },
})