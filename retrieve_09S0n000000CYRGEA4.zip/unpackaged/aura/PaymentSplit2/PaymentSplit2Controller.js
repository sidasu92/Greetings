({
    doInit : function(component, event, helper) {
        var action = component.get('c.getCountriesSelectList');
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            component.set('v.allYears', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    onSelectYear : function(component, event, helper) {
        // method to get selected year and populate Project picklist based on that
        var action = component.get('c.filterProjects');
        //console.log(component.find("years"));
        action.setParams({ yearVal : component.find("years").get("v.value")});
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            //console.log('actionResult.getReturnValue(): '+actionResult.getReturnValue());
            component.set('v.filteredProjects', actionResult.getReturnValue());
            component.set('v.classVar', );  
        });
        $A.enqueueAction(action);
    },
    populateReceivable : function(component, event, helper) {
        // method to pass Project Id and Year value to populate related Receivables and Splits
        var action = component.get('c.relatedReceivable');
        action.setParams({opportunityId : component.find("projects").get("v.value"), yearVal : component.find("years").get("v.value")});
        action.setCallback(this, function(actionResult){
            //console.log('populateReceivable actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());  
        });
        $A.enqueueAction(action);
    },
    addSplitWrapperJS : function(component, event, helper) {
        var action = component.get('c.addSplitWrapper');
        var usrCls = event.currentTarget.getAttribute("data-data") || event.currentTarget.parentNode.getAttribute("data-data")
        //console.log(usrCls);
        //console.log(JSON.stringify(component.get("v.classVar")));
        action.setParams({ 'controllerVarJSON' : JSON.stringify(component.get("v.classVar")) });
        action.setCallback(this, function(actionResult){
            //console.log('populateReceivable actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    removeSplitWrapperJS : function(component, event, helper) {
        var userId = event.currentTarget.getAttribute("data-data") || event.currentTarget.parentNode.getAttribute("data-data")
        //console.log(userId);
        var action = component.get('c.removeSplitWrapper');
        action.setParams({ 'controllerVarJSON' : JSON.stringify(component.get("v.classVar")), 'userId' : userId, 'opptyId' : component.find("projects").get("v.value"), 'yearVal' : component.find("years").get("v.value")});
        action.setCallback(this, function(actionResult){
            //console.log('removeSplitWrapperJS actionResult: ' + actionResult.getReturnValue());
            component.set('v.classVar', actionResult.getReturnValue());
            helper.calculateAllSum(component);
        });
        $A.enqueueAction(action);
    },
    handleChildComponentEvent : function(component, event, helper) {
        // get the selected Account record from the COMPONENT event 	 
        var selectedUserGetFromEvent = event.getParam("userByEvent");
        //console.log('selectedUserGetFromEvent in parent: : ');
        //console.log(selectedUserGetFromEvent.Name);
        
        var action = component.get('c.updateUser');
        action.setParams({'userName' : selectedUserGetFromEvent.Name, 'userId' : selectedUserGetFromEvent.Id, 'lstSplitWrapperJSON' : JSON.stringify(component.get("v.classVar.lstSplitWrapper"))});
        action.setCallback(this, function(actionResult) {
            //console.log('handleChildComponentEvent actionResult: ');
            //console.log(actionResult.getReturnValue());
            component.set('v.classVar.lstSplitWrapper', actionResult.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    checkSum : function(component, event, helper) {

        var whichOne = event.getSource().getLocalId();
        //console.log('whichOne: '+whichOne);
        var getAll = [];
        // handle undefined when only one row of receivable is present
        var receviables = component.find(whichOne);
        //console.log('receviables:'+receviables.length);
        if(receviables.length != undefined) {
            getAll = component.find(whichOne);
        } else {
            getAll.push(component.find(whichOne));
        }
        var sum = 0;
        //console.log('getAll:: ');
        //console.log(getAll[0]);
        // play a for loop and check every checkbox values 
        // if value is checked(true) then add those Id (store in Text attribute on checkbox) in tempIDs var.
        for (var i = 0; i < getAll.length; i++) {
            //console.log('in for loop for sum');
            //console.log(getAll[i].get("v.value"));
            sum+=parseFloat(getAll[i].get("v.value"));
        }
        // set sum value
        var sumCls = whichOne.replace(/P\s*$/, "");
        component.find(sumCls).set("v.value", sum);
        var changeCls = component.find(sumCls).get("v.class");
		//console.log(changeCls);        
        if(changeCls.includes('red')) {
            if(sum < 101) {
                changeCls = changeCls.replace("red", "");
                //console.log('in if '+changeCls); 
                component.find(sumCls).set("v.class", changeCls);
                component.find("splitSubmitBtn").set("v.class", "showSubmitBtn");
            } else {
                //do nothing
            }
        } else {
            if(sum > 100) {
                changeCls+=' red';
                component.find(sumCls).set("v.class", changeCls);
                //console.log(component.find("splitSubmitBtn"));
                component.find("splitSubmitBtn").set("v.class", "hideSubmitBtn");
                
            } else {
                //do nothing
            }
        }
    },
    closeModal:function(component,event,helper) {
        //  clear receivable Id
        component.set('v.receivableID', '');
        var cmpTarget = component.find('Modalbox');
        var cmpBack = component.find('Modalbackdrop');
        $A.util.removeClass(cmpBack,'slds-backdrop--open');
        $A.util.removeClass(cmpTarget, 'slds-fade-in-open');
    },
    openModal: function(component,event,helper) {
        // get the receivable id and type of receivable in csv
        var receivableId = event.target.id;
        //console.log('receivableId');
        //console.log(receivableId);
        var idTypeArr = []
        idTypeArr = receivableId.split(',');
        //console.log('Id:: '+idTypeArr[0]);
        if(idTypeArr[0] === '') {
            idTypeArr[0] = null;
        }
        //console.log('Id:: '+idTypeArr[0]);
        // set id into variable receivableID for submit use
        component.set('v.receivableID', idTypeArr[0]);
        
        // idTypeArr[1] will contain type of receivable for apex to process
        component.set('v.typeOfReceivable', idTypeArr[1])
        
        // idTypeArr[2] will contain month for apex to process
        component.set('v.selectedMonth', idTypeArr[2]);
        //console.log('month: ' + idTypeArr[2]);
        //console.log('before method:: '+component.get('v.modalFeeLst'));
        // prepare JS to call Apex method to populate Modal
        var action = component.get('c.populateReceivables');
        action.setParams({ 'receivableId' : idTypeArr[0], 'typeOfReceivable' : idTypeArr[1], 'selProject' : component.find("projects").get("v.value")});
        // Set up the callback
        action.setCallback(this, function(actionResult) {
            var lstReceivable = actionResult.getReturnValue();
            // populate in attributes
            component.set('v.modalFeeLst', lstReceivable);
            //console.log('lstReceivable : ' +lstReceivable);
            //console.log(component.get('v.modalFeeLst'));
            var cmpTarget = component.find('Modalbox');
            var cmpBack = component.find('Modalbackdrop');
            $A.util.addClass(cmpTarget, 'slds-fade-in-open');
            $A.util.addClass(cmpBack, 'slds-backdrop--open'); 
        });
        $A.enqueueAction(action);
    },
    submitModal: function(component,event,helper) {
        console.log(component.find("projects").get("v.value") +' : '+  component.get('v.selectedMonth') + component.find("years").get("v.value"));
        // store 8 decimal values in this list to feed to apex controller
        var modalList = [];
        var modVals = component.find("modalValues");
        for (var key in modVals) {
            modalList.push(modVals[key].get("v.value"));
        }
        var action = component.get('c.insertUpdateReceivable');
        action.setParams({'successLst' : modalList, 'receivableId' : component.get('v.receivableID'), 'typeOfReceivable': component.get('v.typeOfReceivable'),'selMonth' : component.get('v.selectedMonth'),'selYear' : component.find("years").get("v.value"), 'selProject' : component.find("projects").get("v.value")});
        action.setCallback(this, function(actionResult) {
            //console.log('submitModal actionResult: ');
            component.set('v.modalFeeLst', );
            helper.populateReceivable(component,event);
            helper.closeModal(component,event);
        });
        $A.enqueueAction(action);
    },
    submitSplitJS : function(component, event, helper) {
        //console.log(JSON.stringify(component.get('v.classVar.lstSplitWrapper')));
        //console.log(component.find("projects").get("v.value") +  component.get('v.selectedMonth') + component.find("years").get("v.value"));
        
        // populate a map of month to receivables        
        var action = component.get('c.submitSplitApex');
        action.setParams({'lstSplitWrapperJSON': JSON.stringify(component.get('v.classVar.lstSplitWrapper')), 'selYear' : component.find("years").get("v.value"), 'selProject' : component.find("projects").get("v.value")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log("From server: " + response.getReturnValue());
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'success',
                    message: 'Success! Split records created!'
                });
                toastEvent.fire();
            }
            else if (state === "INCOMPLETE") {
                // do something
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'error',
                    message: 'Error! Please contact your System Administrator!'
                });
                toastEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    mode: 'dismissable',
                    type: 'error',
                    message: 'Error! Please contact your System Administrator!'
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    validate  : function(component, event, helper) {
        var inp = component.get('janP');
        if(isNaN(inp))
            component.set('janP', inp.substring(0, inp.length - 1));
    }
})